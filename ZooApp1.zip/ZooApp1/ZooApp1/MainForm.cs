﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Collections.Generic;
using System.Text;

namespace ZooApp
{
	public class MainForm : Form
	{
		private Button btnAnimals, btnStaff, btnVisitors, btnSpecies, btnLogout;
		private TextBox txtInfo;

		public MainForm()
		{
			InitializeForm();
		}

		private void InitializeForm()
		{
			this.Text = "Система управления зоопарком";
			this.Size = new Size(600, 400);
			this.StartPosition = FormStartPosition.CenterScreen;

			// Меню
			Panel panel = new Panel();
			panel.BackColor = Color.LightGray;
			panel.Size = new Size(150, 400);
			panel.Dock = DockStyle.Left;
			this.Controls.Add(panel);

			// Кнопки меню
			btnAnimals = new Button();
			btnAnimals.Text = "🐘 Животные";
			btnAnimals.Size = new Size(130, 40);
			btnAnimals.Location = new Point(10, 20);
			btnAnimals.Click += ShowAnimals;
			panel.Controls.Add(btnAnimals);

			btnStaff = new Button();
			btnStaff.Text = "👥 Сотрудники";
			btnStaff.Size = new Size(130, 40);
			btnStaff.Location = new Point(10, 70);
			btnStaff.Click += ShowStaff;
			panel.Controls.Add(btnStaff);

			btnVisitors = new Button();
			btnVisitors.Text = "👨‍👩‍👧‍👦 Посетители";
			btnVisitors.Size = new Size(130, 40);
			btnVisitors.Location = new Point(10, 120);
			btnVisitors.Click += ShowVisitors;
			panel.Controls.Add(btnVisitors);

			// Кнопка для видов животных
			btnSpecies = new Button();
			btnSpecies.Text = "🐾 Виды животных";
			btnSpecies.Size = new Size(130, 40);
			btnSpecies.Location = new Point(10, 170);
			btnSpecies.Click += ShowSpecies;
			panel.Controls.Add(btnSpecies);

			btnLogout = new Button();
			btnLogout.Text = "Выход";
			btnLogout.Size = new Size(130, 40);
			btnLogout.Location = new Point(10, 300);
			btnLogout.BackColor = Color.LightCoral;
			btnLogout.Click += LogoutClick;
			panel.Controls.Add(btnLogout);

			// Область информации
			txtInfo = new TextBox();
			txtInfo.Multiline = true;
			txtInfo.Size = new Size(430, 350);
			txtInfo.Location = new Point(160, 20);
			txtInfo.ScrollBars = ScrollBars.Vertical;
			txtInfo.Font = new Font("Arial", 11);
			txtInfo.Text = "Добро пожаловать в систему управления зоопарком!\n\nВыберите раздел в меню слева.";
			this.Controls.Add(txtInfo);
		}

		private void ShowAnimals(object sender, EventArgs e)
		{
			txtInfo.Text = "🐘 СПИСОК ЖИВОТНЫХ:\n\n" +
						  "Лев Симба - 5 лет\n" +
						  "Слон Дамбо - 12 лет\n" +
						  "Тигр Шерхан - 7 лет\n" +
						  "Жираф Мелман - 8 лет\n" +
						  "Обезьяна Чита - 3 года\n" +
						  "Панда По - 4 года\n" +
						  "Зебра Марти - 6 лет\n\n" +
						  "Всего животных: 25";
		}

		private void ShowStaff(object sender, EventArgs e)
		{
			txtInfo.Text = "👥 СОТРУДНИКИ:\n\n" +
						  "Анна - Главный зоолог\n" +
						  "Михаил - Ветеринар\n" +
						  "Ольга - Смотритель\n" +
						  "Иван - Смотритель\n" +
						  "Елена - Администратор\n" +
						  "Дмитрий - Экскурсовод\n\n" +
						  "Всего сотрудников: 15";
		}

		private void ShowVisitors(object sender, EventArgs e)
		{
			txtInfo.Text = "👨‍👩‍👧‍👦 ИНФОРМАЦИЯ О ПОСЕТИТЕЛЯХ:\n\n" +
						  "Часы работы: 9:00-18:00\n" +
						  "Цены:\n" +
						  "  Взрослые: 500 руб\n" +
						  "  Дети: 250 руб\n" +
						  "  Пенсионеры: 300 руб\n\n" +
						  "Экскурсии: каждый час\n" +
						  "Групповые скидки: 20%";
		}

		private void ShowSpecies(object sender, EventArgs e)
		{
			SpeciesForm speciesForm = new SpeciesForm();
			speciesForm.ShowDialog();
		}

		private void LogoutClick(object sender, EventArgs e)
		{
			LoginForm login = new LoginForm();
			login.Show();
			this.Close();
		}
	}

	// Класс для хранения данных о видах животных
	public class AnimalSpecies
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public string LatinName { get; set; }
		public string Lifespan { get; set; }
		public string Description { get; set; }
		public DateTime DateAdded { get; set; }
	}

	// Класс для управления базой данных
	public static class ZooDatabase
	{
		private static string projectFolder = Path.GetDirectoryName(Application.ExecutablePath);
		private static string dataFolder = Path.Combine(projectFolder, "ZooApp_Data");
		private static string dbFile = Path.Combine(dataFolder, "species_database.txt");
		private static string backupFile = Path.Combine(dataFolder, "backup", $"backup_{DateTime.Now:yyyyMMdd_HHmmss}.txt");
		private static string reportFile = Path.Combine(dataFolder, "reports", $"report_{DateTime.Now:yyyyMMdd}.txt");
		private static string individualFilesFolder = Path.Combine(dataFolder, "individual_species");

		private static List<AnimalSpecies> allSpecies = new List<AnimalSpecies>();

		// Инициализация папок
		public static void InitializeFolders()
		{
			try
			{
				// Создаем основную папку
				if (!Directory.Exists(dataFolder))
					Directory.CreateDirectory(dataFolder);

				// Создаем папку для резервных копий
				string backupFolder = Path.Combine(dataFolder, "backup");
				if (!Directory.Exists(backupFolder))
					Directory.CreateDirectory(backupFolder);

				// Создаем папку для отчетов
				string reportsFolder = Path.Combine(dataFolder, "reports");
				if (!Directory.Exists(reportsFolder))
					Directory.CreateDirectory(reportsFolder);

				// Создаем папку для отдельных файлов каждого вида
				if (!Directory.Exists(individualFilesFolder))
					Directory.CreateDirectory(individualFilesFolder);

				Console.WriteLine($"Папка данных: {dataFolder}");
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Ошибка создания папок: {ex.Message}");
			}
		}

		// Загрузка всех данных из файла
		public static void LoadDatabase()
		{
			InitializeFolders();
			allSpecies.Clear();

			if (!File.Exists(dbFile))
			{
				CreateSampleData();
				SaveDatabase();
				return;
			}

			try
			{
				using (StreamReader reader = new StreamReader(dbFile, Encoding.UTF8))
				{
					string line;
					while ((line = reader.ReadLine()) != null)
					{
						string[] parts = line.Split('|');
						if (parts.Length >= 6)
						{
							AnimalSpecies species = new AnimalSpecies
							{
								Id = int.Parse(parts[0]),
								Name = parts[1],
								LatinName = parts[2],
								Lifespan = parts[3],
								Description = parts[4],
								DateAdded = DateTime.Parse(parts[5])
							};
							allSpecies.Add(species);
						}
					}
				}

				// Также загружаем все отдельные файлы для проверки
				LoadIndividualFiles();
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Ошибка загрузки базы данных: {ex.Message}");
			}
		}

		// Загрузка отдельных файлов видов
		private static void LoadIndividualFiles()
		{
			try
			{
				string[] files = Directory.GetFiles(individualFilesFolder, "species_*.txt");
				Console.WriteLine($"Найдено {files.Length} отдельных файлов видов");
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Ошибка загрузки отдельных файлов: {ex.Message}");
			}
		}

		// Сохранение всех данных
		public static void SaveDatabase()
		{
			try
			{
				InitializeFolders();

				// 1. Сохраняем в основной файл БД
				SaveMainDatabase();

				// 2. Создаем резервную копию
				CreateBackup();

				// 3. Сохраняем каждый вид в отдельный файл
				SaveIndividualSpeciesFiles();

				// 4. Создаем отчет
				CreateReport();

				Console.WriteLine($"Данные сохранены в папку: {dataFolder}");
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Ошибка сохранения базы данных: {ex.Message}");
			}
		}

		// Сохранение в основной файл БД
		private static void SaveMainDatabase()
		{
			using (StreamWriter writer = new StreamWriter(dbFile, false, Encoding.UTF8))
			{
				writer.WriteLine("=== БАЗА ДАННЫХ ВИДОВ ЖИВОТНЫХ ===");
				writer.WriteLine($"Дата сохранения: {DateTime.Now}");
				writer.WriteLine($"Всего записей: {allSpecies.Count}");
				writer.WriteLine("==================================\n");

				foreach (var species in allSpecies)
				{
					string line = $"{species.Id}|{species.Name}|{species.LatinName}|" +
								 $"{species.Lifespan}|{species.Description}|" +
								 $"{species.DateAdded:yyyy-MM-dd HH:mm:ss}";
					writer.WriteLine(line);
				}
			}
		}

		// Создание резервной копии
		private static void CreateBackup()
		{
			string backupFolder = Path.Combine(dataFolder, "backup");
			string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
			string backupPath = Path.Combine(backupFolder, $"backup_{timestamp}.txt");

			File.Copy(dbFile, backupPath, true);
		}

		// Сохранение каждого вида в отдельный файл
		private static void SaveIndividualSpeciesFiles()
		{
			foreach (var species in allSpecies)
			{
				string fileName = $"species_{species.Id:000}_{species.Name.Replace(" ", "_")}.txt";
				string filePath = Path.Combine(individualFilesFolder, fileName);

				using (StreamWriter writer = new StreamWriter(filePath, false, Encoding.UTF8))
				{
					writer.WriteLine("╔════════════════════════════════════════╗");
					writer.WriteLine($"║            ВИД ЖИВОТНОГО              ║");
					writer.WriteLine($"║               #{species.Id:000}                  ║");
					writer.WriteLine("╚════════════════════════════════════════╝\n");

					writer.WriteLine($"🆔 ID: {species.Id}");
					writer.WriteLine($"📛 НАЗВАНИЕ: {species.Name}");
					writer.WriteLine($"🔤 ЛАТИНСКОЕ НАЗВАНИЕ: {species.LatinName}");
					writer.WriteLine($"⏳ ПРОДОЛЖИТЕЛЬНОСТЬ ЖИЗНИ: {species.Lifespan}");
					writer.WriteLine($"\n📝 ОПИСАНИЕ:");
					writer.WriteLine($"{species.Description}");
					writer.WriteLine($"\n📅 ДАТА ДОБАВЛЕНИЯ: {species.DateAdded:dd.MM.yyyy HH:mm}");
					writer.WriteLine($"💾 ДАТА СОХРАНЕНИЯ: {DateTime.Now:dd.MM.yyyy HH:mm}");
					writer.WriteLine($"\n══════════════════════════════════════════");
				}
			}
		}

		// Создание отчета
		private static void CreateReport()
		{
			string reportsFolder = Path.Combine(dataFolder, "reports");
			string reportPath = Path.Combine(reportsFolder, $"report_{DateTime.Now:yyyyMMdd}.txt");

			using (StreamWriter writer = new StreamWriter(reportPath, false, Encoding.UTF8))
			{
				writer.WriteLine("╔═════════════════════════════════════════════════╗");
				writer.WriteLine("║            ОТЧЕТ ПО БАЗЕ ДАННЫХ                ║");
				writer.WriteLine("║              ЗООПАРК ZOOAPP                    ║");
				writer.WriteLine("╚═════════════════════════════════════════════════╝\n");

				writer.WriteLine($"📅 Дата отчета: {DateTime.Now:dd.MM.yyyy HH:mm:ss}");
				writer.WriteLine($"📊 Всего видов животных: {allSpecies.Count}");
				writer.WriteLine($"💾 Папка данных: {dataFolder}");
				writer.WriteLine("═".PadRight(60, '═') + "\n");

				writer.WriteLine($"📁 ФАЙЛЫ БАЗЫ ДАННЫХ:");
				writer.WriteLine($"  • Основная БД: species_database.txt");
				writer.WriteLine($"  • Отдельные файлы видов: {allSpecies.Count} файлов");
				writer.WriteLine($"  • Резервные копии: в папке backup/");
				writer.WriteLine($"  • Отчеты: в папке reports/");

				writer.WriteLine($"\n📋 СПИСОК ВСЕХ ВИДОВ:");
				writer.WriteLine("─".PadRight(60, '─'));
				foreach (var species in allSpecies)
				{
					writer.WriteLine($"\n[#{species.Id:000}] {species.Name}");
					writer.WriteLine($"   Латинское: {species.LatinName}");
					writer.WriteLine($"   Продолжительность жизни: {species.Lifespan}");
					writer.WriteLine($"   Добавлен: {species.DateAdded:dd.MM.yyyy}");
				}

				writer.WriteLine($"\n\n🎯 ИТОГО:");
				writer.WriteLine($"Всего сохранено файлов: {allSpecies.Count + 2}");
				writer.WriteLine($"Последнее обновление: {DateTime.Now:dd.MM.yyyy HH:mm}");
				writer.WriteLine($"Следующая резервная копия: {DateTime.Now.AddDays(1):dd.MM.yyyy}");
				writer.WriteLine("\n╔═════════════════════════════════════════════════╗");
				writer.WriteLine("║               КОНЕЦ ОТЧЕТА                     ║");
				writer.WriteLine("╚═════════════════════════════════════════════════╝");
			}
		}

		// Создание примерных данных
		private static void CreateSampleData()
		{
			allSpecies.Add(new AnimalSpecies
			{
				Id = 1,
				Name = "Африканский лев",
				LatinName = "Panthera leo",
				Lifespan = "10-14 лет",
				Description = "Крупный хищник, социальное животное, живет в прайдах",
				DateAdded = DateTime.Now
			});

			allSpecies.Add(new AnimalSpecies
			{
				Id = 2,
				Name = "Азиатский слон",
				LatinName = "Elephas maximus",
				Lifespan = "60-70 лет",
				Description = "Крупное млекопитающее, обладает высоким интеллектом",
				DateAdded = DateTime.Now
			});

			allSpecies.Add(new AnimalSpecies
			{
				Id = 3,
				Name = "Большая панда",
				LatinName = "Ailuropoda melanoleuca",
				Lifespan = "20 лет",
				Description = "Медведь, питающийся бамбуком, символ Китая",
				DateAdded = DateTime.Now
			});
		}

		// Получение всех видов
		public static List<AnimalSpecies> GetAllSpecies()
		{
			return new List<AnimalSpecies>(allSpecies);
		}

		// Добавление вида
		public static bool AddSpecies(AnimalSpecies species)
		{
			if (allSpecies.Exists(s => s.Id == species.Id))
				return false;

			species.DateAdded = DateTime.Now;
			allSpecies.Add(species);
			SaveDatabase();
			return true;
		}

		// Удаление вида
		public static bool DeleteSpecies(int id)
		{
			var species = allSpecies.Find(s => s.Id == id);
			if (species == null)
				return false;

			allSpecies.Remove(species);

			// Удаляем отдельный файл вида
			try
			{
				string fileName = $"species_{id:000}_*.txt";
				string[] files = Directory.GetFiles(individualFilesFolder, fileName);
				foreach (string file in files)
				{
					File.Delete(file);
				}
			}
			catch { }

			SaveDatabase();
			return true;
		}

		// Поиск вида по ID
		public static AnimalSpecies GetSpeciesById(int id)
		{
			return allSpecies.Find(s => s.Id == id);
		}

		// Получение информации о файлах
		public static string GetFilesInfo()
		{
			InitializeFolders();
			string info = $"📁 ПАПКА ДАННЫХ: {dataFolder}\n\n";

			// Основная БД
			if (File.Exists(dbFile))
			{
				var dbInfo = new FileInfo(dbFile);
				info += $"📄 Основная БД: species_database.txt\n";
				info += $"   Размер: {dbInfo.Length / 1024} КБ\n";
				info += $"   Создан: {dbInfo.CreationTime:dd.MM.yyyy}\n";
			}

			// Отдельные файлы
			if (Directory.Exists(individualFilesFolder))
			{
				string[] files = Directory.GetFiles(individualFilesFolder, "*.txt");
				info += $"\n📄 Отдельные файлы видов: {files.Length} файлов\n";
			}

			// Резервные копии
			string backupFolder = Path.Combine(dataFolder, "backup");
			if (Directory.Exists(backupFolder))
			{
				string[] backups = Directory.GetFiles(backupFolder, "*.txt");
				info += $"\n💾 Резервные копии: {backups.Length} файлов\n";
			}

			return info;
		}
	}

	// Форма для управления видами животных
	public class SpeciesForm : Form
	{
		private TextBox txtId, txtName, txtLatinName, txtLifespan, txtDescription;
		private Button btnAdd, btnRefresh, btnClear, btnDelete, btnExport, btnStats, btnOpenFolder;
		private ListBox listSpecies;
		private TextBox txtDetails;
		private Label lblStats;
		private Label lblFolderInfo;

		public SpeciesForm()
		{
			InitializeForm();
			LoadDatabase();
			RefreshSpeciesList();
			UpdateStatistics();
		}

		private void InitializeForm()
		{
			this.Text = "Управление видами животных - База данных ZooApp";
			this.Size = new Size(1000, 700);
			this.StartPosition = FormStartPosition.CenterScreen;

			// Панель ввода данных
			Panel inputPanel = new Panel();
			inputPanel.BorderStyle = BorderStyle.FixedSingle;
			inputPanel.Location = new Point(20, 20);
			inputPanel.Size = new Size(280, 280);
			this.Controls.Add(inputPanel);

			int yPos = 20;

			// Поля ввода на панели (только необходимые)
			CreateLabelOnPanel(inputPanel, "ID вида:", 20, yPos);
			txtId = CreateTextBoxOnPanel(inputPanel, 120, yPos, 140);
			yPos += 30;

			CreateLabelOnPanel(inputPanel, "Название:", 20, yPos);
			txtName = CreateTextBoxOnPanel(inputPanel, 120, yPos, 140);
			yPos += 30;

			CreateLabelOnPanel(inputPanel, "Латинское:", 20, yPos);
			txtLatinName = CreateTextBoxOnPanel(inputPanel, 120, yPos, 140);
			yPos += 30;

			CreateLabelOnPanel(inputPanel, "Срок жизни:", 20, yPos);
			txtLifespan = CreateTextBoxOnPanel(inputPanel, 120, yPos, 140);
			yPos += 30;

			CreateLabelOnPanel(inputPanel, "Описание:", 20, yPos);
			txtDescription = CreateTextBoxOnPanel(inputPanel, 120, yPos, 140);
			yPos += 40;

			// Кнопки управления на панели
			btnAdd = new Button() { Text = "➕ Добавить", Location = new Point(20, yPos), Size = new Size(120, 30), BackColor = Color.LightGreen };
			btnDelete = new Button() { Text = "❌ Удалить", Location = new Point(150, yPos), Size = new Size(120, 30), BackColor = Color.LightCoral };
			yPos += 40;

			btnClear = new Button() { Text = "🧹 Очистить", Location = new Point(20, yPos), Size = new Size(120, 30), BackColor = Color.LightYellow };
			btnRefresh = new Button() { Text = "🔄 Обновить", Location = new Point(150, yPos), Size = new Size(120, 30), BackColor = Color.LightBlue };
			yPos += 40;

			btnExport = new Button() { Text = "💾 Сохранить", Location = new Point(20, yPos), Size = new Size(120, 30), BackColor = Color.LightGray };
			btnStats = new Button() { Text = "📊 Статистика", Location = new Point(150, yPos), Size = new Size(120, 30), BackColor = Color.LightPink };
			yPos += 40;

			btnOpenFolder = new Button() { Text = "📁 Открыть папку", Location = new Point(20, yPos), Size = new Size(250, 30), BackColor = Color.LightSkyBlue };

			inputPanel.Controls.AddRange(new Control[] { btnAdd, btnDelete, btnClear, btnRefresh, btnExport, btnStats, btnOpenFolder });

			// Список видов
			listSpecies = new ListBox();
			listSpecies.Location = new Point(320, 20);
			listSpecies.Size = new Size(300, 250);
			listSpecies.Font = new Font("Arial", 10);
			listSpecies.SelectedIndexChanged += ListSpecies_SelectedIndexChanged;
			this.Controls.Add(listSpecies);

			// Детальная информация
			txtDetails = new TextBox();
			txtDetails.Multiline = true;
			txtDetails.Location = new Point(320, 290);
			txtDetails.Size = new Size(640, 350);
			txtDetails.ScrollBars = ScrollBars.Vertical;
			txtDetails.Font = new Font("Arial", 10);
			txtDetails.ReadOnly = true;
			this.Controls.Add(txtDetails);

			// Информация о папке
			lblFolderInfo = new Label();
			lblFolderInfo.Location = new Point(20, 320);
			lblFolderInfo.Size = new Size(280, 100);
			lblFolderInfo.Font = new Font("Arial", 8);
			lblFolderInfo.BorderStyle = BorderStyle.FixedSingle;
			lblFolderInfo.BackColor = Color.WhiteSmoke;
			this.Controls.Add(lblFolderInfo);

			// Статистика
			lblStats = new Label();
			lblStats.Location = new Point(20, 440);
			lblStats.Size = new Size(280, 200);
			lblStats.Font = new Font("Arial", 9);
			lblStats.BorderStyle = BorderStyle.FixedSingle;
			lblStats.BackColor = Color.WhiteSmoke;
			this.Controls.Add(lblStats);

			// События кнопок
			btnAdd.Click += AddSpecies;
			btnDelete.Click += DeleteSpecies;
			btnClear.Click += ClearFields;
			btnRefresh.Click += RefreshList;
			btnExport.Click += ExportData;
			btnStats.Click += ShowStatistics;
			btnOpenFolder.Click += OpenDataFolder;

			// Загрузка базы данных
			ZooDatabase.LoadDatabase();
		}

		private void CreateLabelOnPanel(Panel panel, string text, int x, int y)
		{
			Label label = new Label() { Text = text, Location = new Point(x, y), Size = new Size(90, 20) };
			panel.Controls.Add(label);
		}

		private TextBox CreateTextBoxOnPanel(Panel panel, int x, int y, int width)
		{
			TextBox textBox = new TextBox() { Location = new Point(x, y), Size = new Size(width, 20) };
			panel.Controls.Add(textBox);
			return textBox;
		}

		private void LoadDatabase()
		{
			ZooDatabase.LoadDatabase();
		}

		private void RefreshSpeciesList()
		{
			listSpecies.Items.Clear();
			var species = ZooDatabase.GetAllSpecies();
			foreach (var s in species)
			{
				listSpecies.Items.Add($"{s.Id:000}. {s.Name}");
			}
		}

		private void AddSpecies(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(txtId.Text) || string.IsNullOrEmpty(txtName.Text))
			{
				MessageBox.Show("Заполните ID и название вида!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			try
			{
				AnimalSpecies species = new AnimalSpecies
				{
					Id = int.Parse(txtId.Text),
					Name = txtName.Text,
					LatinName = txtLatinName.Text,
					Lifespan = txtLifespan.Text,
					Description = txtDescription.Text
				};

				if (ZooDatabase.AddSpecies(species))
				{
					MessageBox.Show("Вид успешно добавлен и сохранен в файлы!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ClearFields(null, null);
					RefreshSpeciesList();
					UpdateStatistics();
				}
				else
				{
					MessageBox.Show("Вид с таким ID уже существует!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void DeleteSpecies(object sender, EventArgs e)
		{
			if (listSpecies.SelectedIndex == -1)
			{
				MessageBox.Show("Выберите вид для удаления!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			string selected = listSpecies.SelectedItem.ToString();
			int id = int.Parse(selected.Split('.')[0]);

			if (MessageBox.Show($"Вы уверены, что хотите удалить вид #{id}?\nФайл вида также будет удален.",
				"Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				if (ZooDatabase.DeleteSpecies(id))
				{
					MessageBox.Show("Вид успешно удален из базы данных!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
					RefreshSpeciesList();
					txtDetails.Clear();
					UpdateStatistics();
				}
			}
		}

		private void ListSpecies_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (listSpecies.SelectedIndex != -1)
			{
				string selected = listSpecies.SelectedItem.ToString();
				int id = int.Parse(selected.Split('.')[0]);
				var species = ZooDatabase.GetSpeciesById(id);

				if (species != null)
				{
					string details = $"🐘 ДЕТАЛЬНАЯ ИНФОРМАЦИЯ О ВИДЕ (ID: {species.Id})\n";
					details += "═".PadRight(70, '═') + "\n";
					details += $"📛 НАЗВАНИЕ: {species.Name}\n";
					details += $"🔤 ЛАТИНСКОЕ НАЗВАНИЕ: {species.LatinName}\n";
					details += $"⏳ ПРОДОЛЖИТЕЛЬНОСТЬ ЖИЗНИ: {species.Lifespan}\n";
					details += $"\n📝 ОПИСАНИЕ:\n{species.Description}\n";
					details += $"\n📅 ДАТА ДОБАВЛЕНИЯ: {species.DateAdded:dd.MM.yyyy HH:mm}\n";
					details += "═".PadRight(70, '═');

					txtDetails.Text = details;
				}
			}
		}

		private void ClearFields(object sender, EventArgs e)
		{
			txtId.Clear();
			txtName.Clear();
			txtLatinName.Clear();
			txtLifespan.Clear();
			txtDescription.Clear();
			txtId.Focus();
		}

		private void RefreshList(object sender, EventArgs e)
		{
			ZooDatabase.LoadDatabase();
			RefreshSpeciesList();
			UpdateStatistics();
			MessageBox.Show("База данных обновлена!", "Обновление", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void ExportData(object sender, EventArgs e)
		{
			ZooDatabase.SaveDatabase();
			string folderPath = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "ZooApp_Data");

			MessageBox.Show($"✅ ДАННЫЕ УСПЕШНО СОХРАНЕНЫ!\n\n" +
						  $"📁 Папка данных: {folderPath}\n\n" +
						  $"Созданы файлы:\n" +
						  $"• 📄 species_database.txt (основная база данных)\n" +
						  $"• 📄 Отдельные файлы для каждого вида\n" +
						  $"• 💾 Резервная копия в папке backup/\n" +
						  $"• 📊 Отчет в папке reports/\n\n" +
						  $"Всего файлов: {ZooDatabase.GetAllSpecies().Count + 3}",
						  "Сохранение данных", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void ShowStatistics(object sender, EventArgs e)
		{
			string filesInfo = ZooDatabase.GetFilesInfo();
			var species = ZooDatabase.GetAllSpecies();

			MessageBox.Show($"📊 ПОЛНАЯ СТАТИСТИКА БАЗЫ ДАННЫХ\n\n" +
						  $"{filesInfo}\n\n" +
						  $"📈 СТАТИСТИКА ПО ВИДАМ:\n" +
						  $"Всего видов: {species.Count}\n" +
						  $"Последнее обновление: {DateTime.Now:dd.MM.yyyy HH:mm}\n\n" +
						  $"📍 Файлы сохраняются в папке проекта\n" +
						  $"   в подпапке 'ZooApp_Data'",
						  "Статистика базы данных", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void OpenDataFolder(object sender, EventArgs e)
		{
			try
			{
				string folderPath = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "ZooApp_Data");
				if (!Directory.Exists(folderPath))
				{
					Directory.CreateDirectory(folderPath);
				}
				System.Diagnostics.Process.Start("explorer.exe", folderPath);
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Ошибка открытия папки: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void UpdateStatistics()
		{
			var species = ZooDatabase.GetAllSpecies();
			string folderPath = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "ZooApp_Data");

			// Информация о папке
			lblFolderInfo.Text = $"📁 ПАПКА ДАННЫХ:\n" +
							   $"{folderPath}\n\n" +
							   $"📍 Все файлы сохраняются\n" +
							   $"   в этой папке проекта";

			// Статистика
			lblStats.Text = $"📊 СТАТИСТИКА БАЗЫ ДАННЫХ\n" +
						   $"═══════════════════════\n" +
						   $"Всего видов: {species.Count}\n" +
						   $"Обновлено: {DateTime.Now:HH:mm}\n\n" +
						   $"📄 ФАЙЛЫ В ПАПКЕ:\n" +
						   $"• species_database.txt\n" +
						   $"• {species.Count} файлов видов\n" +
						   $"• Отчеты в reports/\n" +
						   $"• Резервные копии в backup/\n\n" +
						   $"💾 Нажмите 'Сохранить'\n" +
						   $"   для создания файлов";
		}
	}
}