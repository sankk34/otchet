﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ZooApp
{
	public class LoginForm : Form
	{
		private TextBox txtUsername, txtPassword;
		private Button btnLogin, btnExit;

		public LoginForm()
		{
			InitializeForm();
		}

		private void InitializeForm()
		{
			this.Text = "Зоопарк - Вход";
			this.Size = new Size(400, 300);
			this.StartPosition = FormStartPosition.CenterScreen;
			this.BackColor = Color.LightBlue;

			// Заголовок
			Label lblTitle = new Label();
			lblTitle.Text = "Система управления зоопарком";
			lblTitle.Font = new Font("Arial", 14, FontStyle.Bold);
			lblTitle.ForeColor = Color.DarkGreen;
			lblTitle.Size = new Size(300, 30);
			lblTitle.Location = new Point(50, 30);
			this.Controls.Add(lblTitle);

			// Логин
			Label lblUser = new Label();
			lblUser.Text = "Логин:";
			lblUser.Location = new Point(50, 80);
			lblUser.Size = new Size(100, 20);
			this.Controls.Add(lblUser);

			txtUsername = new TextBox();
			txtUsername.Location = new Point(150, 80);
			txtUsername.Size = new Size(200, 20);
			txtUsername.Text = "admin";
			this.Controls.Add(txtUsername);

			// Пароль
			Label lblPass = new Label();
			lblPass.Text = "Пароль:";
			lblPass.Location = new Point(50, 120);
			lblPass.Size = new Size(100, 20);
			this.Controls.Add(lblPass);

			txtPassword = new TextBox();
			txtPassword.Location = new Point(150, 120);
			txtPassword.Size = new Size(200, 20);
			txtPassword.PasswordChar = '*';
			txtPassword.Text = "1234";
			this.Controls.Add(txtPassword);

			// Кнопки
			btnLogin = new Button();
			btnLogin.Text = "Войти";
			btnLogin.Location = new Point(100, 170);
			btnLogin.Size = new Size(80, 30);
			btnLogin.BackColor = Color.LightGreen;
			btnLogin.Click += LoginClick;
			this.Controls.Add(btnLogin);

			btnExit = new Button();
			btnExit.Text = "Выход";
			btnExit.Location = new Point(220, 170);
			btnExit.Size = new Size(80, 30);
			btnExit.BackColor = Color.LightCoral;
			btnExit.Click += ExitClick;
			this.Controls.Add(btnExit);
		}

		private void LoginClick(object sender, EventArgs e)
		{
			if (txtUsername.Text == "admin" && txtPassword.Text == "1234")
			{
				MainForm main = new MainForm();
				main.Show();
				this.Hide();
			}
			else
			{
				MessageBox.Show("Неверный логин или пароль!");
			}
		}

		private void ExitClick(object sender, EventArgs e)
		{
			Application.Exit();
		}
	}
}